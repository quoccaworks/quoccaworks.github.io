<?php

ini_set('display_errors', 1);

define("ROOT_DIR", __DIR__);
define("APP_DIR", ROOT_DIR . "/app");

require_once "accela/loader.php";
route(el($_SERVER, "PATH_INFO", "/"));
