<?php

ini_set('display_errors', 1);

require_once "accela/loader.php";
route(el($_SERVER, "PATH_INFO", "/"));
