ACCELA.init_page = function(){
  $("#accela").hide().fadeIn(500);
};

ACCELA.move_page = function(page_content, move){
  let content;

  if($(".document-layout").length > 0 && page_content.find(".document-layout").length > 0){
    move();

  }else if($(".lower").length > 0 && page_content.find(".lower").length > 0){
    $(".lower").fadeOut(200, function(){
      move();
      $(".lower").hide().fadeIn(200);
    })

  }else{
    $("#accela").fadeOut(200, function(){
      move();
      $("#accela").fadeIn(400);
    })
  }
};

ACCELA.change_page_content = function(body, page_content){
  body.html(page_content);
  hljs.highlightAll();
};


ACCELA.modules.lang_switcher = function(ul){
  return;
  const href = location.pathname;

  if(href.match("/en/")){
    ul.find("li:not(.lang) a").each(function(){
      $(this).attr("href", $(this).attr("href").replace("/accela/", "/accela/en/"));
    });
    ul.find("li.lang a").first().attr("href", href.replace("/en/", "/"));
    ul.find("li.lang a").last().replaceWith("<span>en</span>");
  }else{
    ul.find("li:not(.lang) a").each(function(){
      $(this).attr("href", $(this).attr("href").replace("/en/", "/"));
    });
    ul.find("li.lang a").last().attr("href", href.replace("/accela/", "/accela/en/"));
    ul.find("li.lang a").first().replaceWith("<span>ja</span>");
  }
};

ACCELA.modules.document_nav_toggle = function(object){
  object.on("click", function(){
    if(!$(".side").is(".opened")) $("html,body").stop().animate({scrollTop: 0});
    $(".side").toggleClass("opened");
  });
};

ACCELA.modules.count_down_redirect = function(object){
  object.text("3秒後にAccelaのトップページにリダイレクトします。");
  setTimeout(() => object.text("2秒後にAccelaのトップページにリダイレクトします。"), 1000);
  setTimeout(() => object.text("1秒後にAccelaのトップページにリダイレクトします。"), 2000);
  setTimeout(() => location.href = "/accela/", 3000);
};

ACCELA.modules.background_image = function(object){
  const $w = $(window);
  const $canvas = $('<canvas width="1600" height="1200" id="bg"></canvas>');
  object.html($canvas);

  const ctx = $canvas[0].getContext("2d");
  const rand = function(max){return Math.floor(Math.random() * max);};

  $canvas.hide();

  (function(){
    const grad = ctx.createLinearGradient(0, 0, 1600, 1200);
    grad.addColorStop(0, "rgb(255, 245, 245)");
    grad.addColorStop(1, "rgb(250, 235, 235)");
    ctx.fillStyle = grad;
    ctx.rect(0, 0, 1600, 1200);
    ctx.fill();

    let n, i, j;
    ctx.globalCompositeOperation = "xor";
    for(i=0; i<7; i++){
      n = 200 + rand(20);
      ctx.fillStyle = "rgba("+(n+rand(30))+", "+(n+rand(30))+", "+(n+rand(30))+", 0.25)";
      ctx.beginPath();
      ctx.moveTo(rand(3200)-800, rand(2400)-600);
      for(j=0; j<3; j++){
        ctx.lineTo(rand(3200)-800, rand(2400)-600);
      }
      ctx.fill();
      ctx.closePath();
    }
  })();

  $canvas.fadeIn(500);
}
