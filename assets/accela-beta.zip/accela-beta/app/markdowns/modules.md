# モジュール

`app/script.js`

クライアントサイドで動的なコンテンツを扱いたい場合は、モジュール機能を使うとシンプルに記述できます。

コンポーネント、サーバコンポーネント、モジュールの違いは、[動的処理の比較](../dynamic-functions/)を参照してください。

## 基本

script.js内で`ACCELA.modules`に関数を追加していき、テンプレート内で`data-use-module`を使ってその関数を呼び出します。

<div class="code-with-caption">

`script.js`
```javascript
ACCELA.modules.uppercase = function(object){
  object.text(object.text().toUpperCase());
};
```

`index.html`
```html
<div data-use-module="uppercase">accela</div>
↓
<div>ACCELA</div>
```
</div>

引数の`object`には、**呼び出された&lt;div /&gt;のjQueryオブジェクト**が渡されるため、以下の操作が可能です。
- object.attr("attr") の取得
- object.html(), object.text() の取得
- object.html(other_object) によるinnerHTMLの書き換え


## 非同期
`object`が保持されている間は、いつでもinnerHTMLの更新が可能なため、非同期な更新も実装できます。

<div class="code-with-caption">

`script.js`
```javascript
// カウントダウン
ACCELA.modules.async_module = function(object){
  object.text("3");
  setTimeout(() => object.text("2"), 1000);
  setTimeout(() => object.text("1"), 2000);
  setTimeout(() => object.text("done."), 3000);
};

// ローディングとウィジェットの読み込み
ACCELA.modules.load_widget = function(object){
  object.html('<div class="loading">loading</div>');

  $.get("/api/widget", function(data){
    object.html(data);
  });
};
```
</div>

## バインディングとの連携
[Page Props](../page-props/)と[値のバインディング](../binding/)を使って、バインドした値をモジュールで扱うこともできます。

<div class="code-with-caption">

`index.html`
```html
<div data-use-module="a" data-bind="data-id:id" data-bind-text="text">
</div>
```

`script.js`
```javascript
ACCELA.modules.a = function(object){
  const id = object.data("id");
  const text = object.text();
  ...
};
```
</div>


## モジュールの拡張、委譲

モジュールは単なるJavaScriptの関数なので、モジュールから別のモジュールを呼ぶことで、処理を委譲することができます。

<div class="code-with-caption">

`page-init.php`
```javascript
ACCELA.modules.repeat = function(object){
  const count = object.data("count") ? object.data("count") : 1;
  object.html(object.html().repeat(count));
};

ACCELA.modules.repeat10 = function(object){
  object.data("count", 10);
  ACCELA.modules.repeat(object);
};
```
</div>

以下の2つのulは等価です。

<div class="code-with-caption">

`index.html`
```html
<ul data-use-module="repeat" data-count="10">
  <li></li>
</ul>

<ul data-use-module="repeat10">
  <li></li>
</ul>
```
</div>
