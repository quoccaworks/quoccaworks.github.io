# サーバコンポーネント
`app/server-components/*.php`

コンポーネントはjQueryでレンダリングされますが、サーバコンポーネントを使えばサーバサイドで動的な処理を行うことができます。

コンポーネント、サーバコンポーネント、モジュールの違いは、[動的処理の比較](../dynamic-functions/)を参照してください。

## 注意点

呼び出しの記法はコンポーネントとほぼ変わりませんが、動作原理が違う点にご注意ください。

サーバコンポーネントを使うと、処理された段階で全てHTML上に展開されてJSONデータに埋め込まれるため、ファイルサイズが大きくなる可能性があります。
複雑な処理が必要ないものは、まず[Page Props](../page-props/)と[コンポーネント](../components/)を使った実装を検討してください。


## 例1 メタタグ
### サーバコンポーネントの定義

<div class="code-with-caption">

`app/server-components/meta.php`
```html
<title><?php echo el($props, 'title'); ?></title>
<meta name="description" content="<?php echo el($props, 'description'); ?>">
<meta name="keywords" content="<?php echo el($props, 'keywords'); ?>">
<!-- OGP -->
<meta ...>
```
</div>

[el()の詳細はこちら](../functions/)


### サーバコンポーネントの使用
サーバコンポーネントの使用には、独自タグ **&lt;server-component use="" /&gt;** を使用します。
このタグは、コンポーネントと同様、DOM上からは無くなります。

<div class="code-with-caption">

`app/pages/index.html`
```html
<head>
  <server-component use="meta"
    title="Accela PHP Web Framework"
    description="Accela is a PHP Framework that inspired by Next.js."
    keywords="accela,php,web framework,next.js">
  </server-component>
</head>
...
```
</div>
