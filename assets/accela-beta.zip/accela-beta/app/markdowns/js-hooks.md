# ページ移動時のフック
`app/script.js`

ページの初期表示時、ページ移動時のフックを使えば、アニメーションや差分レンダリングを実装することができます。


## ACCELA.init_page
最初にサイト内のページにアクセスされた時に1回だけ実行される処理を記述します。
- フェードイン
- ローディング
- Webフォントの読み込み待ち

など。

```javascript
ACCELA.init_page = function(){
  $("#accela").hide().fadeIn(500);
};
```


## ACCELA.move_page
ページ移動時に実行される処理を記述します。最初のアクセス時には実行されません。
- ページ遷移アニメーション
- トラッキングの追加

など。

### 第1引数
移動先ページのコンテンツのjQueryオブジェクトが渡されます。
このDOM構造を比較することで、ページの種類ごとにアニメーションを変更することもできます。

### 第2引数
実際にDOMの更新をするための関数が渡されます。
`move_page`内で必ず1回だけ実行する必要があります。

```javascript
ACCELA.move_page = function(page_content, move){
  $("#accela").fadeOut(200, function(){
    move();
    $("#accela").fadeIn(400);
  })
};
```


## ACCELA.change_page_content
ページ移動のDOMの更新処理を変更することができます。
このフックを使うと、DOMの差分レンダリングが可能になります。


```javascript
ACCELA.change_page_content = function(body, page_content){
  body.html(page_content);
};
```
