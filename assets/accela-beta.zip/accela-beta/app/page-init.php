<?php

namespace Accela;

function get_titles(){
  return [
    "about" => ["Accelaとは", "accela"],
    "structure" => ["ファイル構成", "accela"],
    "common-html" => ["サイトの共通情報", "html"],
    "templates" => ["テンプレート", "html"],
    "routing" => ["ルーティング", "accela"],
    "dynamic-routing" => ["動的ルーティング", "accela"],
    "components" => ["コンポーネント", "html"],
    "binding" => ["値のバインディング", "accela"],
    "page-paths" => ["Page Paths", "php"],
    "page-props" => ["Page Props", "php"],
    "modules" => ["モジュール", "js"],
    "built-in-modules" => ["ビルトインモジュール", "js"],
    "js-hooks" => ["ページ移動時のフック", "js"],
    "static-site-generation" => ["静的ビルド", "accela"]
  ];
}

function get_document_nav($current_slug=null){
  $html = "<ul>";
  foreach(get_titles() as $slug => $set){
    if($current_slug === $slug){
      $html .= "<li class=\"{$set[1]}\"><a href=\"../{$slug}/\" class=\"current\">{$set[0]}</a></li>";
    }else{
      $html .= "<li class=\"{$set[1]}\"><a href=\"../{$slug}/\">{$set[0]}</a></li>";
    }
  }
  return $html . "</ul>";
}

// ドキュメントTOP
page_props("/accela/doc/", function(){
  return [
    "document-nav" => get_document_nav()
  ];
});

// ドキュメント下層
page_paths("/accela/doc/[slug]/", function(){
  return array_map(function($slug){
    return "/accela/doc/{$slug}/";
  }, array_keys(get_titles()));
});

page_props("/accela/doc/[slug]/", function($query){
  $slug = $query["slug"];
  $file_path = APP_DIR . "/markdowns/{$slug}.md";

  return [
    "title" => get_titles()[$slug][0] . " - Accela Document",
    "slug" => $slug,
    "document-nav" => get_document_nav($slug),
    "md" => file_exists($file_path) ? file_get_contents($file_path) : "",
  ];
});
