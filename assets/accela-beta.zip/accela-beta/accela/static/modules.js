ACCELA.modules.markdown = (object) => object.html(marked(object.html()));

ACCELA.modules.unescape_markdown = (function(){
  const patterns = {
    '&lt;'   : '<',
    '&gt;'   : '>',
    '&amp;'  : '&',
    '&quot;' : '"',
    '&#x27;' : '\'',
    '&#x60;' : '`'
  };

  const unescape = (text) => {
    return text.replace(/&(lt|gt|amp|quot|#x27|#x60);/g, function(match) {
      return patterns[match];
    });
  };

  return (object) => object.html(marked(unescape(object.html())))
})();
