/* --------------------------------------------------
 * Accela
 */

jQuery.fn.extend({
  attrs: function(){
    const attrs = {}, _attrs = this[0].attributes;
    for(let i=0, len=_attrs.length; i<len; i++){
      attrs[_attrs[i].name] = _attrs[i].value;
    }

    return attrs;
  },

  accela_bind_props: function(props){
    if(typeof props === "undefined") throw new Error("props is undefined");
    this.find("[data-bind]").each(function(){
      const o = $(this);
      $(this).data("bind").split(",").forEach(function(set){
        const [prop, variable] = set.split(":");
        if(!variable) variable = prop;
        o.attr(prop, props[variable]);
      });
    });

    this.find("[data-bind-html]").each(function(){
      $(this).html(props[$(this).data("bind-html")]);
    });

    this.find("[data-bind-text]").each(function(){
      $(this).text(props[$(this).data("bind-text")]);
    });
  },

  accela_apply_components: function(components, _props={}, depth=1){
    if(depth > 1000) throw new Error("error!");

    this.each(function(){
      const o = $(this);

      if(o.is("component")){
        const props = o.attrs();
        $.each(props, function(k, v){
          if(k[0] === "@" && _props[v]){
            delete props[k];
            props[k.slice(1)] = _props[v];
          }
        });

        const component_name = o.attr("use");
        const component = components[component_name];
        if(!component) throw new Error(`component ${component_name} is not exists`);

        const component_object = component.object.clone();
        component_object.accela_bind_props(props);

        component_object.find("[data-contents='"+component_name+"']").html(o.contents());
        component_object.accela_apply_components(components, props, depth+1);
        o.replaceWith(component_object.find("> *"));
      }else{
        o.find("> *").accela_apply_components(components, _props, depth+1);
      }
    });

    return this;
  },

  accela_apply_modules: function(depth=1){
    if(depth > 1000) throw new Error("error!");

    this.each(function(){
      const o = $(this);

      if(o.is("[data-use-module]") && ACCELA.modules[o.attr("data-use-module")]){
        ACCELA.modules[o.attr("data-use-module")](o);

      }else{
        o.find("> *").accela_apply_modules(depth+1);
      }
    });
  },

  accela_merge_replace: function(content){
  },
});

(function($){
  class Page {
    constructor(page){
      this.path = page.path;
      this.head = new PageHead(page.path, page.head, page.props);
      this.content = new PageContent(page.path, page.content, page.props);
    }
  }

  class PageHead {
    constructor(path, head, props){
      this.object = $("<accela:head>").append(head);
      this.object.accela_bind_props(props);
    }

    html(){
      return this.object.html();
    }
  }

  class PageContent {
    constructor(path, content, props){
      this.object = $("<accela:content />").append(content);
      this.path = path;
      this.props = props;
      this.object.accela_bind_props(props);
    }

    html(){
      const object = this.object.find("> *").clone();
      object.accela_apply_modules();
      return object;
    }

    apply_components(components){
      this.object.accela_apply_components(components, this.props);
    }

    apply_modules(){
      // this.object.accela_apply_modules();
    }
  }

  class Component {
    constructor(name, component){
      this.object = $("<accela:component>").append(component);
      this.object.data("name", name);
      this.object.find("[data-contents]").attr("data-contents", name);
    }
  }

  const head = $("head"),
        body = $("#accela");

  const components = {};
  $.each(ACCELA.components, function(name, component){
    components[name] = new Component(name, component);
  });

  const move_page = function(page, is_first){
    if(!ACCELA.change_page_content){
      ACCELA.change_page_content = function(body, page_content){
        body.html(page_content);
      };
    }

    const page_content = page.content.html();

    const move = function(){
      $("html,body").scrollTop(0);
      head.find("[name='accela-separator']").nextAll(":not(.accela-css)").remove();
      head.append(page.head.html());
      ACCELA.change_page_content(body, page_content);
      body.attr("data-page-path", page.path);
    }
    if(is_first){
      if(ACCELA.init_page) ACCELA.init_page();
      move();
    }else{
      ACCELA.move_page ? ACCELA.move_page(page_content, move) : move();
    }
  };

  const first_page = new Page(ACCELA.entrance_page);
  first_page.content.apply_components(components);

  move_page(first_page, true);


  $.getJSON(`/assets/site.json?__t=${ACCELA.utime}`, function(_site){
    const site = {};
    $.each(_site, function(path, _page){
      const page = new Page(_page);
      page.content.apply_components(components);
      site[path] = page;
    });

    $("body").on("click", "a", function(e){
      if(e.metaKey || e.shiftKey || e.altKey) return true;

      //let path = $(this).attr("href");
      let url = new URL($(this).attr("href"), location.href);
      let path = url.pathname;
      if(!site[path]) return true;

      if(path === location.pathname) return false;

      move_page(site[path]);
      history.pushState(null, null, path);

      return false;
    });

    window.onpopstate = function(e){
      if(e.originalEvent && !e.originalEvent.state) return;
      move_page(site[location.pathname]);
    }
  });
})(jQuery);
