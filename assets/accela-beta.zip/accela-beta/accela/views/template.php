<!DOCTYPE html>
<html>
<head><?php echo Accela\get_header_html($page); ?></head>
<body>
<style>
<?php echo (Accela\PageCommon::instance())->get_css(); ?>
<?php echo implode("\n", array_filter(array_map(function($p){return $p->get_css();}, Accela\Page::all()))); ?>
</style>
<div id="accela"></div>
<script>const ACCELA = <?php echo json_encode(Accela\get_initial_data($page)); ?>; ACCELA.modules = {};</script>
<script src="/assets/js/accela.js?__t=<?php echo el($_GET, "__t", time()); ?>" defer></script>
</body>
</html>
