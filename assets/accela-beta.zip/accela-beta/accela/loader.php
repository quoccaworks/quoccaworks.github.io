<?php

namespace Accela;

define("ROOT_DIR", realpath(__DIR__ . "/.."));
define("APP_DIR", ROOT_DIR . "/app");

require_once __DIR__ . "/includes/scss.inc.php";
require_once __DIR__ . "/includes/classes/Component.php";
require_once __DIR__ . "/includes/classes/Page.php";
require_once __DIR__ . "/includes/classes/PageCommon.php";
require_once __DIR__ . "/includes/classes/PageProps.php";
require_once __DIR__ . "/includes/classes/PagePaths.php";
require_once __DIR__ . "/includes/functions.php";
require_once __DIR__ . "/includes/router.php";
require_once APP_DIR . "/page-init.php";
