<?php

namespace {
  function el($o, $key, $default=null){
    if(is_array($o)){
      return isset($o[$key]) ? $o[$key] : $default;
    }else{
      return isset($o->$key) ? $o->$key : $default;
    }
  }
}

namespace Accela {
  function get_initial_data($page){
    return [
      "entrance_page" => [
        "path" => $page->path,
        "head" => $page->head,
        "content" => $page->body,
        "props" => $page->props
      ],
      "components" => get_components(),
      "utime" => el($_GET, "__t", time()),
    ];
  }

  function get_components(){
    $components = [];
    foreach(Component::all() as $name => $component){
      $components[$name] = $component->content;
    }
    return $components;
  }

  function get_header_html($page){
    $common_page = PageCommon::instance();
    $separator = "\n<meta name=\"accela-separator\">\n";
    return $common_page->head . $separator . $page->head;
  }

  function is_dynamic_path($path){
    return preg_match("@\\[.+?\\]@", $path);
  }
}
