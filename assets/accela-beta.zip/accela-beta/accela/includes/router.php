<?php

function route($path){
  if($path === "/assets/site.json"){
    header("Content-Type: application/json");
    $pages = array_map(function($page){
      return [
        "path" => $page->path,
        "head" => $page->head,
        "content" => $page->body,
        "props" => $page->props
      ];
    }, Accela\Page::all());
    echo json_encode($pages);
    exit;
  }

  if($path === "/assets/js/accela.js"){
    header("Content-Type: text/javascript");
    echo file_get_contents(__DIR__ . "/../static/jquery.min.js");
    echo file_get_contents(__DIR__ . "/../static/marked.min.js");
    echo file_get_contents(__DIR__ . "/../static/modules.js");
    echo file_get_contents(APP_DIR . "/script.js");
    echo file_get_contents(__DIR__ . "/../static/accela.js");
    exit;
  }

  if($path === "/accela-admin/build"){
    require_once __DIR__ . "/classes/StaticSiteGenerator.php";
    Accela\StaticSiteGenerator::output();
    echo "export to `out/` directory";
    exit;
  }

  $path_info = el($_SERVER, "PATH_INFO", "/");

  try{
    $page = new Accela\Page($path_info);
  }catch(Accela\PageNotFoundError $e){
    $page = new Accela\Page("/404");
    http_response_code(404);
  }
  require_once __DIR__ . "/../views/template.php";
}
